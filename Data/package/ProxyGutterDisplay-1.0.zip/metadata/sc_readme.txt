Installing this package deploys a DLL to the bin directory, and creates a content item in the Core database to enable the Proxies gutter icon.  No further action should be required to enable this feature. 

If you run into any issues, please post feedback to this location: https://github.com/dsolovay/Sitecore-Proxy-Gutter-Icon/issues